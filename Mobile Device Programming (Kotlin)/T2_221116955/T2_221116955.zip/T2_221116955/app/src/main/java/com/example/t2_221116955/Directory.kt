package com.example.t2_221116955

import java.util.concurrent.locks.Lock

//Primary constructor for yatim objects
open class Directory(open var name: String) {
    open var parent:Directory? = null
    var content = arrayListOf<Directory>()
    //Seconday Contructor (For files that have parents)
    constructor(name:String, parent: Directory?): this(name){
        this.parent = parent
    }

    constructor(name:String, content:ArrayList<Directory>) : this(name) {
        this.content = content
    }

    fun mkdir(name:String){
        this.content.add(Directory(name,this))
    }

    fun ls(){
        for (c in content){
            if(c is File || c is BombFile || c is LockFile){
                print("[FILE]")
            }
            else if(c is Directory){
                print("[FOLDER]")
            }
            println(" ${c.name}")
        }
    }

    fun getDir():String{
        if(parent != null){
            return parent!!.getDir() + name
        }
        else{
            return name+"/"
        }
    }

}
package com.example.t2_221116955

open class LockFile (override var name:String) : Directory(name) {
    var data:Data = Data("")
}

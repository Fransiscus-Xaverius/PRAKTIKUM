package com.example.t2_221116955

//data class
data class Data(val str: String) {

    companion object {
        // Function to create a Data object with an empty string
        fun empty(): Data {
            return Data("")
        }

        // Function to create a Data object with a string in uppercase
        fun withUpperCase(str: String): Data {
            return Data(str.uppercase())
        }
    }
}

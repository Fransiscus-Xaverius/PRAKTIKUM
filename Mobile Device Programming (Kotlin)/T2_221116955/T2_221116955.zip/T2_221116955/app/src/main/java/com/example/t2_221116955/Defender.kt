package com.example.t2_221116955

import kotlin.random.Random

class Defender(var curDirObj:Directory, var root:ArrayList<Directory>) {
    var locked:Int = 0;
    var isDead:Boolean = false;
    fun randNum(limit:Int):Int = Random(System.nanoTime()).nextInt(0, limit)

    fun move(){
        if(locked == 0){
            var temp: ArrayList<Directory> = curDirObj!!.content
            curDirObj!!.parent?.let { temp.add(it) }
            temp += root
            var idx:Int = randNum(temp.size)
            this.curDirObj = curDirObj!!.content[idx]
//            println(curDirObj.name)
            if(this.curDirObj is LockFile) {
                locked+=3
            }
        }
        else{
            locked--
        }
    }

    fun getCurDirContent(): ArrayList<Directory>{
        return this.curDirObj!!.content
    }

    fun checkDeath(){
        var idx:Int = curDirObj.content.indexOfFirst { it is BombFile }
        if(idx>-1){
            this.isDead = true
            curDirObj.content.removeAt(curDirObj.content.indexOfFirst { it is BombFile })
            println("A Bomb file has taken out a defender!")
        }
    }

}
package com.example.t2_221116955

import kotlin.random.Random

var GLOBAL_CHEAT: String = ""

//NOTE UNTUK PEMERIKSA
//TOLONG JANGAN UNCOMMENT CODE DI LINE 295. JIKA CODE DI UNCOMMENT MAKA GAME AKAN MENJADI UNPLAYABLE
//KARENA SETIAP DEFENDER PASTI SPAWN DI SALAH SATU FOLDER UTAMA (A,B, ATAU D) GAME AKAN MENJADI UNPLAYABLE KARENA ATTACKER PASTI AKAN TERTANGKAP DEFENDER

fun menu(){
    println("==Hack the System==")
    println("Main Menu")
    println("1. Play")
    println("2. Leaderboard")
    println("3. Exit")
    print(">>")
}

fun chooseDiff(){
    println("Choose Difficulty")
    println("1. Easy")
    println("2. Normal")
    println("3. Hard")
    print(">>")
}

fun stupidRecursive(arr:Array<String>):ArrayList<Directory>{
    var list:ArrayList<Directory> = arrayListOf()
    var keyGenerated:Boolean = false
    while(!keyGenerated){
        list = arrayListOf()
        var parentDir:Directory? = null
        for (e in arr){
            var dirs: ArrayList<ArrayList<String>> = arrayListOf(e.split("/").toCollection(ArrayList()))
            for (d in dirs){
                if(d.size==1){
                    list.add(Directory(d[0]))
                }
                else{
                    var curDir: ArrayList<Directory> = list
                    while (d.size>0){
                        var idx:Int = list.indexOfFirst { it.name == d[0] }
                        if(idx>-1){
                            parentDir = list[idx]
                            curDir = list[idx].content
                            d.removeAt(0)
                        }
                        else{
                            var temp = Directory(d[0],parentDir)
                            curDir.add(temp)
                            curDir = temp.content
                            parentDir = temp
                            d.removeAt(0)
                        }
                        if(!keyGenerated){
                            if(randNum(10)==1){
                                curDir?.let {
                                    curDir.add(File("key"))
                                    keyGenerated = true
                                    GLOBAL_CHEAT = parentDir.getDir() //cheat
//                                    print("generated")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return list
}

fun randNum(limit:Int):Int = Random(System.currentTimeMillis()).nextInt(1, limit)

//stupid recursive function for debugging array.
fun stupidRecursivePrint(arr:ArrayList<Directory>){
    for(e in arr){
        if(!e.content.isEmpty()){
//           print(e.name+"/")
           stupidRecursivePrint(e.content)
        }
        else{
            print(e.name)
        }
        println()
    }
}

fun dirExist(curDirectory: Directory, name:String):Boolean{
    return curDirectory.content.indexOfFirst { it.name == name } > -1
}

fun main(){

    var arrayFolder:Array<String> = arrayOf("A", "B", "C", "D", "A/Apel", "A/Mangga", "A/Jambu", "A/Pepaya", "B/Apel",
    "B/Mangga", "B/Jambu", "B/Pepaya", "C/Apel", "C/Mangga", "C/Jambu", "C/Pepaya", "D/Apel",
    "D/Mangga", "D/Jambu", "D/Pepaya", "D/Pepaya/Hijau")

    var game:Boolean = true;

    var directories:ArrayList<Directory> = stupidRecursive(arrayFolder)
    var defenders:ArrayList<Defender> = arrayListOf()

    while(game){
        menu()
        var opt:Int? = readlnOrNull()!!.toIntOrNull()
        opt?.let {
            when(opt){
                1->{
                    var choosingDiff:Boolean = true
                    var diffOpt:Int? = 0
                    while(choosingDiff){
                        chooseDiff()
                        diffOpt = readlnOrNull()!!.toIntOrNull()
                        diffOpt?.run {
                            if(diffOpt in 1..3){
                                choosingDiff = false
                            }
                        }
                    }
                    for (i in 1..diffOpt!!){
                        var tempObj:Directory? = directories[randNum(directories.size-1)]

                        while (tempObj!!.name == "C"){
                            tempObj = directories[randNum(directories.size-1)]
                        }
                        defenders.add(Defender(tempObj, directories))
                    }
                    println(defenders.size)
                    var run:Boolean = true //running game
                    var curDir:String = ""
                    curDir = directories[directories.indexOfFirst { it.name == "C" }].getDir()
                    var curDirObj:Directory = directories[directories.indexOfFirst { it.name == "C" }]
                    var step:Int = 0
                    var gameOver:Boolean = false
                    while(run){
                        println("==Game Mode==")
                        println("Current Directory: ${curDir}")
                        print(">>")
                        var com:String? = readlnOrNull().toString()
                        com?.let {
                            var validCmd:Boolean = false
                            var cmd: List<String> = com.split(" ")
                            when(cmd[0]){
                                "ls"->{
                                    curDirObj.ls()
                                    validCmd = true
                                }
                                "cd"->{
//                                    print(cmd[1])
                                    if(cmd.size>1){
                                        var exist:Boolean = dirExist(curDirObj, cmd[1])
                                        if(exist){
                                            if(curDirObj.content[curDirObj.content.indexOfFirst { it.name == cmd[1] }] is File){
                                                println("ERROR! You can’t enter a file")
                                                validCmd = true
                                            }
                                            else{
                                                curDirObj = curDirObj.content[curDirObj.content.indexOfFirst { it.name == cmd[1] }]
                                                curDir= curDirObj.getDir()
                                                validCmd = true
                                            }
                                        }
                                        else if(cmd[1]==".."){
                                            if(curDirObj.parent != null){
                                                curDirObj = curDirObj.parent!! //again, stupid null checker.
                                                curDir = curDirObj.getDir()
                                                validCmd = true
                                            }
                                            else{
                                                //if the directory has no parent.
                                                //doesn't do anything. This is just to satisfy this stupid language.
                                            }
                                        }
                                        else{
                                            exist = directories.indexOfFirst { it.name == cmd[1] }>-1
                                            if(exist){
                                                curDirObj = directories[directories.indexOfFirst { it.name == cmd[1] }]
                                                curDir = curDirObj.getDir()
                                                validCmd = true
                                            }
                                            else{
                                                //this branch does nothing. Its here just to make this stupid language run without screaming at me.
                                            }
                                        }
                                    }
                                    else{
                                        println("Invalid command.")
                                    }
                                }
                                "rm" -> {
                                    if(cmd.size>1){
                                        var idx = curDirObj.content.indexOfFirst { it.name == cmd[1] && it is File || it.name == cmd[1] && it is LockFile || it.name == cmd[1] && it is BombFile}
                                        if(idx>-1){
                                            curDirObj.content.removeAt(idx)
                                        }
                                        else{
                                            idx = curDirObj.content.indexOfFirst { it.name == cmd[1] }
                                            if(idx>-1){
                                                println("ERROR! You can't delete a folder")
                                            }
                                            else{
                                                println("ERROR! File “${cmd[1]}” not found")
                                            }
                                        }
                                    }
                                    else{
                                        println("ERROR! file name not given!")
                                    }
                                }
                                "mkdir" -> {
                                    //this should be recursive. Because the curDirObj will refer to the current Directory from its parent Directory.
                                    if(cmd.size>1){
                                        var idx = curDirObj.content.indexOfFirst { it.name == cmd[1] }
                                        if(idx>-1){
                                            println("ERROR! A folder name “${cmd[1]}” already exist.")
                                            validCmd = true
                                        }
                                        else{
                                            curDirObj.content.add(Directory(cmd[1]))
                                            validCmd = true
                                        }
                                    }
                                    else{
                                        println("ERROR! Folder name not given!")
                                    }
                                }
                                "touch_common" -> {
                                    if(cmd.size>1){
                                        validCmd = true
                                        var idx = curDirObj.content.indexOfFirst { it.name == cmd[1] && it is File}
                                        if(idx>-1){
                                            println("ERROR! A file named “${cmd[1]}” already exist.")
                                        }
                                        else{
                                            curDirObj.content.add(File(cmd[1]))
                                        }
                                    }
                                    else{
                                        println("ERROR! File name not given!")
                                    }
                                }
                                "touch_lock" -> {
                                    validCmd = true
                                    if(cmd.size>1){
                                        var idx = curDirObj.content.indexOfFirst { it.name == cmd[1] && it is File}
                                        if(idx>-1){
                                            println("ERROR! A file named “${cmd[1]}” already exist.")
                                        }
                                        else{
                                            curDirObj.content.add(LockFile(cmd[1]))
                                        }
                                    }
                                    else{
                                        println("ERROR! File name not given!")
                                    }
                                }
                                "touch_bomb" -> {
                                    validCmd = true
                                    if(cmd.size>1){
                                        var idx = curDirObj.content.indexOfFirst { it.name == cmd[1] && it is File}
                                        if(idx>-1){
                                            println("ERROR! A file named “${cmd[1]}” already exist.")
                                        }
                                        else{
                                            curDirObj.content.add(BombFile(cmd[1]))
                                        }
                                    }
                                    else{
                                        println("ERROR! File name not given!")
                                    }
                                }
                                "peek" -> {
                                    validCmd = true
                                    for(d in defenders){
                                        println(d.curDirObj.getDir())
                                    }
                                }
                                "cheat" -> {
                                    validCmd = true
                                    println("Key is located at ${GLOBAL_CHEAT}")
                                }
                                "surrend" -> { //Saya mau surrend bikin ini h-1. Soalnya terlalu susah bang.
                                    run = false
                                    println("Game over, you lose")
                                }
                                else -> {

                                }
                            }
                            if(validCmd){
                                for(d in defenders){
                                    d.move()
                                    d.checkDeath()
                                }
                                defenders = defenders.filter { !it.isDead } as ArrayList<Defender>
                                step++
//                                println("Current whereabouts")
//                                for (d in defenders){
//                                    var t:String = d.curDirObj.getDir()
//                                    println(t)
//                                    println(curDirObj.getDir())
//                                    if(t == curDirObj.getDir()){
//                                        gameOver = true
//                                    }
//                                    else{
//                                        println("not same")
//                                    }
//                                }

//                                if(gameOver){
//                                    run = false
//                                    println("You have been deleted by the defender. Game Over.")
//                                }
                            }
                        }
                        com?.run {

                        }
                    }
                }
                2->{

                }
                3->{
                    game = false
                }
                else->{

                }
            }
        }
        opt?.run {

        }
    }
}

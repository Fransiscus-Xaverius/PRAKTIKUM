package com.example.t2_221116955

open class File (override var name:String) : Directory(name) {
    var data:Data = Data("")
}